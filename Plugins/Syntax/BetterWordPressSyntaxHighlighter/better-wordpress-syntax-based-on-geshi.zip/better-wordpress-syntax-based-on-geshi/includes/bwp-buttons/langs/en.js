tinyMCE.addI18n({en:{
BWPSyntax:{
desc : 'BWP Syntax - Insert or highlight a codeblock'
}}});
