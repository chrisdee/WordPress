<?php
include_once(dirname(__FILE__). '/better-wordpress-syntax-based-on-geshi/bwp-syntax.php');
?>